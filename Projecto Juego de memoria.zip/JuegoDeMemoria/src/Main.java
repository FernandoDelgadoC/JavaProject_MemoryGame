import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    //Aqui va el bucle para poder repetir el ejercicio
    	Scanner sc = new Scanner(System.in);
    	String respuesta;
    	do {
    		
    		System.out.println("¡Juego de Memoria!");
        	System.out.println();
            String[][] cartas = {
                    {"Rima", "Espada", "Autopista", "Fax", "Vocal", "Viaje", "Caballete", "Espina", "Venda", "Filtro"},
                    {"Espiar", "Plancha", "Guerra", "Transporte", "Humano", "Lluvia", "Monstruo", "Eleccion", "Laser", "Raton"},
                    {"Raton", "Plancha", "Espiar", "Guerra", "Transporte", "Lluvia", "Laser", "Eleccion", "Humano", "Monstruo"},
                    {"Venda", "Viaje", "Filtro", "Vocal", "Fax", "Espada", "Autopista", "Caballete", "Rima", "Espina"},
                    {"Bola", "Patas", "Atleta", "Registro", "Silla", "Tortuga", "Tuerca", "Canasta", "Ancla", "Tiempo"}, 
                    {"Globo", "Robo", "Sangre", "Motor", "Libro", "Metal", "Programa", "Nivel", "Millon", "Alga"},
                    {"Volumen", "Historia", "Ojo", "Mano", "Ombligo", "Lila", "Marco", "Cura", "Punto", "Santa"},
                    {"Ancla", "Tiempo", "Atleta", "Bola", "Tortuga", "Silla", "Registro", "Canasta", "Tuerca", "Patas"},
                    {"Metal", "Globo", "Libro", "Nivel", "Robo", "Programa", "Millon", "Sangre", "Alga", "Motor"},
                    {"Ombligo" , "Punto", "Ojo", "Mano", "Volumen", "Santa", "Historia", "Cura", "Lila", "Marco"},     
                    };
            // Aqui ingresamos todas las palabras
            boolean[][] cartasSeleccionadas = new boolean[12][10];;
            // Aqui ingresamos la cantidad de filas y columnas
            int aciertos = 0;
            int intentos = 0; 
            boolean invalido=true; //Variable que va a indicar si el valor ingresado es valido o invalido
            // Se declara las variables como enteros
            
            while(intentos < 1) {
            	// El while es para que finalize luego de 10 intentos
                mostrarCartas(cartas, cartasSeleccionadas);
                int carta1Fila, carta1Columna, carta2Fila, carta2Columna;
                // Se declara las variables como enteros 
                
                invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                
                //Ciclo que verifica si el valor ingresado es un entero.
                while(invalido)
    			{
                    System.out.print("Seleccione la fila de su primera carta: ");
    				if(sc.hasNextInt())
    				{
    					invalido=false;//Sale del ciclo
    				}
    				else
    				{
    					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
    					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
    					invalido=true;
    				}
    			}
                
                carta1Fila = sc.nextInt() - 1;
                // al valor ingresado del usuario se resta uno ya que para el ls filas comienzan en uno y no en cero
                
                //Comprueba que el numero ingresado no sobrepase lo que acepta el arreglo
                while(carta1Fila<0||carta1Fila>10)
                {
                	System.out.println("El número de fila que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                    
                	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice

                	//Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la fila de su primera carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}
                    carta1Fila = sc.nextInt() - 1;
                    // al valor ingresado del usuario se resta uno ya que para el ls filas comienzan en uno y no en cero
                }
                
                invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                
                //Ciclo que verifica si el valor ingresado es un entero.
                while(invalido)
    			{
                    System.out.print("Seleccione la columna de su primera carta: ");
    				if(sc.hasNextInt())
    				{
    					invalido=false;//Sale del ciclo
    				}
    				else
    				{
    					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
    					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
    					invalido=true;
    				}
    			}
                
                carta1Columna = sc.nextInt() - 1;
                // al valor ingresado del usuario se resta uno ya que para el las columnas comienzan en uno y no en cero
              //Comprueba que el numero ingresado no sobrepase lo que acepta el arreglo
                while(carta1Columna<0||carta1Columna>10)
                {
                	System.out.println("El número de columna que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                	
                	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    
                    //Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la columna de su primera carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}                    
                    carta1Columna = sc.nextInt() - 1;
                    // al valor ingresado del usuario se resta uno ya que para el las columnas comienzan en uno y no en cero
                }
                //Comprueba que no se selecciona la misma carta
                while(cartasSeleccionadas[carta1Fila][carta1Columna]) {
                    System.out.println("¡Esa carta ya ha sido seleccionada! Intente de nuevo.");
                    invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice

                	//Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la fila de su primera carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}
                    carta1Fila = sc.nextInt() - 1;
                    // al valor ingresado del usuario se le resta uno

                    while(carta1Fila<0||carta1Fila>10)
                    {
                    	System.out.println("El número de fila que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                        
                    	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice

                    	//Ciclo que verifica si el valor ingresado es un entero.
                        while(invalido)
            			{
                            System.out.print("Seleccione la fila de su primera carta: ");
            				if(sc.hasNextInt())
            				{
            					invalido=false;//Sale del ciclo
            				}
            				else
            				{
            					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
            					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
            					invalido=true;
            				}
            			}
                        carta1Fila = sc.nextInt() - 1;
                        // al valor ingresado del usuario se resta uno ya que para el ls filas comienzan en uno y no en cero
                    }

                    invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    
                    //Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la columna de su primera carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}           
                    carta1Columna = sc.nextInt() - 1;
                    // al valor ingresado del usuario se le resta uno
                    while(carta1Columna<0||carta1Columna>10)
                    {
                    	System.out.println("El número de columna que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                    	
                    	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                        
                        //Ciclo que verifica si el valor ingresado es un entero.
                        while(invalido)
            			{
                            System.out.print("Seleccione la columna de su primera carta: ");
            				if(sc.hasNextInt())
            				{
            					invalido=false;//Sale del ciclo
            				}
            				else
            				{
            					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
            					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
            					invalido=true;
            				}
            			}                    
                        carta1Columna = sc.nextInt() - 1;
                        // al valor ingresado del usuario se resta uno ya que para el las columnas comienzan en uno y no en cero
                    }
                }
                
                cartasSeleccionadas[carta1Fila][carta1Columna] = true;
                mostrarCartas(cartas, cartasSeleccionadas);
                //Se muestran las cartas en la pantalla
                
                invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                
                //Ciclo que verifica si el valor ingresado es un entero.
                while(invalido)
    			{
                    System.out.print("Seleccione la fila de su segunda carta: ");
    				if(sc.hasNextInt())
    				{
    					invalido=false;//Sale del ciclo
    				}
    				else
    				{
    					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
    					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
    					invalido=true;
    				}
    			}
                carta2Fila = sc.nextInt() - 1;
                // al valor ingresado del usuario se le resta uno
              //Comprueba que el numero ingresado no sobrepase lo que acepta el arreglo
                while(carta2Fila<0||carta2Fila>10)
                {
                	System.out.println("El número de fila que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                	
                    invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                	
                	while(invalido)
        			{
                        System.out.print("Seleccione la fila de su segunda carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}
                    carta2Fila = sc.nextInt() - 1;
                 // al valor ingresado del usuario se le resta uno
                }
                
                invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                
                //Ciclo que verifica si el valor ingresado es un entero.
                while(invalido)
    			{
                    System.out.print("Seleccione la columna de su segunda carta: ");
    				if(sc.hasNextInt())
    				{
    					invalido=false;//Sale del ciclo
    				}
    				else
    				{
    					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
    					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
    					invalido=true;
    				}
    			}   
                carta2Columna = sc.nextInt() - 1;
             // al valor ingresado del usuario se le resta uno
                
              //Comprueba que el numero ingresado no sobrepase lo que acepta el arreglo
                while(carta2Columna<0||carta2Columna>10)
                {
                	System.out.println("El número de columna que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    
                    //Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la columna de su segunda carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}  
                    carta2Columna = sc.nextInt() - 1;
                 // al valor ingresado del usuario se le resta uno
                }
                //Comprueba que no se haya seleccionado la misma carta
                while(cartasSeleccionadas[carta2Fila][carta2Columna]) {
                    System.out.println("¡Esa carta ya ha sido seleccionada! Intente de nuevo.");
                    invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    
                    //Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la fila de su segunda carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}
                    carta2Fila = sc.nextInt() - 1;
                 // al valor ingresado del usuario se le resta uno
                    while(carta2Fila<0||carta2Fila>10)
                    {
                    	System.out.println("El número de fila que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                    	
                        invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    	
                    	while(invalido)
            			{
                            System.out.print("Seleccione la fila de su segunda carta: ");
            				if(sc.hasNextInt())
            				{
            					invalido=false;//Sale del ciclo
            				}
            				else
            				{
            					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
            					System.out.println("Debe de ingresar un numero entero de las filas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
            					invalido=true;
            				}
            			}
                        carta2Fila = sc.nextInt() - 1;
                     // al valor ingresado del usuario se le resta uno
                    }
                    
                    invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                    
                    //Ciclo que verifica si el valor ingresado es un entero.
                    while(invalido)
        			{
                        System.out.print("Seleccione la columna de su segunda carta: ");
        				if(sc.hasNextInt())
        				{
        					invalido=false;//Sale del ciclo
        				}
        				else
        				{
        					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
        					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
        					invalido=true;
        				}
        			}  
                    carta2Columna = sc.nextInt() - 1;
                 // al valor ingresado del usuario se le resta uno
                     
                    while(carta2Columna<0||carta2Columna>10)
                    {
                    	System.out.println("El número de columna que ingrese debe de ser mayor a 0 y menor o igual a 10.");
                    	invalido=true;//Se establece la variable en true para que cada ves que entre al ciclo se actualice
                        
                        //Ciclo que verifica si el valor ingresado es un entero.
                        while(invalido)
            			{
                            System.out.print("Seleccione la columna de su segunda carta: ");
            				if(sc.hasNextInt())
            				{
            					invalido=false;//Sale del ciclo
            				}
            				else
            				{
            					sc.next();//Para limpiar la variable y que no entre en un bucle sin salida.
            					System.out.println("Debe de ingresar un numero entero de las columnas que se le indican.");//Si el valor no es un entero vuelve a solicitar el valor hasta que sea un formato valido
            					invalido=true;
            				}
            			}  
                        carta2Columna = sc.nextInt() - 1;
                     // al valor ingresado del usuario se le resta uno
                    }
                }
                
                cartasSeleccionadas[carta2Fila][carta2Columna] = true;
                mostrarCartas(cartas, cartasSeleccionadas);
                //muestra las clases
                
                if(cartas[carta1Fila][carta1Columna].equals(cartas[carta2Fila][carta2Columna])) {
                    System.out.println("¡Has hecho una coincidencia!");
                 // Confirma si tiene alguna coincidencia
                    aciertos++;
                    //aumenta la cantidad de aciertos
                } else {
                    System.out.println("Lo siento, intenta de nuevo.");
                    cartasSeleccionadas[carta1Fila][carta1Columna] = false;
                    cartasSeleccionadas[carta2Fila][carta2Columna] = false;
                    // no tiene coincidencias
                    
                	}
                intentos++; // aumentamos intentos
                 }
            
            if(aciertos < 10) { // verificamos si se han alcanzado los 10 intentos
                System.out.println("¡Tus intentos se acabaron! Juego terminado.");
                System.out.println("Usted obtuvo: "+aciertos+" puntos.");
                // se acabaron los intentos y se muestra la cantidad de aciertos que obtuvo
             }
            
    		if(aciertos > 10) { // verificamos si se han alcanzado los 10 intentos
    	        System.out.println("¡Felicidades, encontraste todas las parejas!.");	
    	        System.out.println("Usted obtuvo: "+aciertos+" puntos.");
    	        // completo la memoria y se muestra los aciertos que obtuvo
            }
    		
    		System.out.println("Desea jugar de nuevo? s/n");
    		respuesta = sc.next();
    	}while(respuesta.equalsIgnoreCase("s"));
    	
    	System.out.println("¡Gracias por jugar!");
    	
    	
    	//while ......
    	
        	
     }
       
            public static void mostrarCartas(String[][] cartas, boolean[][] cartasSeleccionadas) {
            	// se crea un metodo de retorno
            	// se retornan las variables cartas y cartasSeleccionadas
                System.out.println("    1   2   3   4   5   6   7   8   9   10");
                for(int i=0; i<10; i++) {
                    System.out.print((i+1) + " | ");
                    for(int j=0; j<10; j++) {
                        if(cartasSeleccionadas[i][j]) {
                            System.out.print(cartas[i][j] + " | ");
                        } else {
                            System.out.print("* | ");
                            // Se crea la tabla del juego
                        }
                    }
                    System.out.println();
                }
                System.out.println();
            }
    		 

        }
